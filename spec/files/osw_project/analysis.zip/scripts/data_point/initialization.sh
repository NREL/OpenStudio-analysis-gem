#!/bin/bash -e

# dummy script
echo "Calling $0 with arguments: $@"

